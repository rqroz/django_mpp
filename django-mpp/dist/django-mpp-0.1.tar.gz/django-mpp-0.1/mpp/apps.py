from django.apps import AppConfig


class MppConfig(AppConfig):
    name = 'mpp'
